TIC-TAC-TOE 3D V. 1.1
README

Spielprinzip:
Auf einem 3�3 Felder gro�en Spielfeld machen zwei Spieler/ ein Spieler und der PC 
abwechselnd ihre Zeichen (Kreuze und Kreise). Der Spieler, der als erstes drei seiner
 Zeichen in einer Reihe, Spalte oder einer der beiden Hauptdiagonalen setzen kann, gewinnt.

Steuerungsm�glichkeiten:
*Hauptmen�:
	-Enter: Men�eintrag ausw�hlen
	-Pfeiltaste hoch/runter: Men�eintrag dr�ber/drunter ausw�hlen 
*Optionen:
	-Enter: Zur�ck ins Hauptmen�
	-Pfeiltaste hoch/runter: Men�eintrag dr�ber/drunter ausw�hlen
	-Pfeiltaste links/rechts: Optionswert �ndern
*Credits:
	-Enter: Zur�ck ins Hauptmen�
*Spiel:
	-Esc: Zur�ck ins Hauptmen�
	-Enter: Kreuz/Kringel auf die Cursor-Position setzen; Nach Spielende: Neues Spiel starten
	-P: Pause
	-Pfeiltaste hoch/runter: Cursor um eine Position nach oben/unten verschieben
	-Pfeiltaste links/rechts: Cursor um eine Position nach links/rechts verschieben
	-Maus: bei gedr�ckter rechter Maustaste: Kamera drehen