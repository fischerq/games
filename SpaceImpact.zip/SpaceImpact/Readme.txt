SPACEIMPACT++
Readme

Space Impact++ ist ein Retro-Weltraumshooter.
Ziel des Spieles ist es, sich durchs Weltall zu schlagen und dabei m�glichst viele Mobs
zu besiegen. Endbosse inklusive! Sammle Items um dir kurzzeitige Powerups zu verschaffen, 
deine Leben aufzuf�llen oder andere Waffen zu erhalten. 

Men�-steuerung:
Pfeil hoch/runter
Enter/Leertaste

Ingame-Steuerung:
Bewegung: WASD/ Pfeiltasten
Schuss: Leertaste
Spezialschuss: c

Credits:
Programmierung: Zera
Grafiken: Tyrael
M�dchen f�r alles: Tecqu *hust* :P