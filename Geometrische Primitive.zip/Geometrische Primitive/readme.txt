Geometrische Primitive
----------------------

Ein Spiel von:
Peter Friedland (Programmierung)
Quirin Fischer (Programmierung, Sounds)
Michael Hussinger (Grafiken)

Credits:

Background Music by playonloop.com (CC-BY 3.0)
http://www.playonloop.com/2012-music-loops/air-ducts/

Affen-Sounds By www.freesound.org (CC-BY 3.0)
http://www.freesound.org/people/sandyrb/sounds/41382/